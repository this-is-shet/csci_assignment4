
import sqlite3
import tempfile
import unittest
from datetime import date
from pathlib import Path

from budgetcash import db
from budgetcash.alert_service import AlertService
from budgetcash.budget_service import BudgetService
from budgetcash.domain import AlertLevel, NotFoundError, TransactionType, ValidationError
from budgetcash.report_service import ReportService
from budgetcash.repositories import (AlertRepository, BudgetRepository, CategoryRepository,
                                     TransactionRepository)
from budgetcash.transaction_service import TransactionService

E, I = TransactionType.EXPENSE, TransactionType.INCOME
NONE, AMBER, RED = AlertLevel.NONE, AlertLevel.APPROACHING, AlertLevel.EXCEEDED
TODAY = date(2026, 11, 19)           # fixed "today" so the tests always give the same result
NOV = date(2026, 11, 10)


class FailingAlertRepository(AlertRepository):
    """Stands in for a database error while saving an alert."""

    def save(self, alert):
        raise sqlite3.OperationalError("database is locked")


class BudgetCashTestCase(unittest.TestCase):
    """Builds the real services on a temporary SQLite database for every test."""

    def setUp(self):
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        self.conn = db.connect(str(Path(temp_dir.name) / "budgetcash_test.sqlite"))
        self.addCleanup(self.conn.close)          # runs first, so Windows can delete the file
        self.tx_repo = TransactionRepository(self.conn)
        self.cat_repo = CategoryRepository(self.conn)
        self.budget_repo = BudgetRepository(self.conn)
        self.alert_repo = AlertRepository(self.conn)
        self.budgets = BudgetService(self.conn, self.budget_repo, self.cat_repo, self.tx_repo)
        self.alerts = AlertService(self.budget_repo, self.alert_repo, self.cat_repo)
        self.transactions = TransactionService(self.conn, self.tx_repo, self.cat_repo,
                                               self.budgets, self.alerts, today=lambda: TODAY)
        self.reports = ReportService(self.tx_repo)

    def new_user(self, email="sonam@example.com"):
        """Register a user (gets the default categories); return (user_id, {name: id})."""
        user_id = db.create_user(self.conn, email)
        names = ("Food", "Transport", "Bills", "Fun", "Salary")
        return user_id, {n: self.cat_repo.find_by_name(user_id, n).id for n in names}

    def level(self, user_id, category_id):
        return self.budget_repo.find(user_id, category_id, 11, 2026).last_alert_level


# ======================================================================================
# COMPONENT 1 - "Add expense and check budget"
# Interface: TransactionService.add_transaction / edit_transaction / delete_transaction
# Inside: TransactionValidator -> TransactionRepository -> BudgetService (sum_by_category,
#         find budget) -> AlertService -> AlertRepository, all in ONE database transaction.
# Tests C1-01 and C1-02 are derived from the Assignment 3 sequence diagram (Figure 4).
# ======================================================================================
class C1AddExpenseComponentTests(BudgetCashTestCase):

    def test_C1_01_expense_under_budget_follows_sequence_diagram(self):
        """C1-01 Validation: Rs 300 expense vs Rs 500 budget is saved, green, no alert."""
        uid, cats = self.new_user()
        self.budgets.set_budget(uid, cats["Food"], 11, 2026, 50000)

        result = self.transactions.add_transaction(uid, 30000, E, cats["Food"], NOV, "Groceries")

        stored = self.tx_repo.find(uid, result.transaction.id)
        self.assertEqual((stored.amount_paisa, stored.date, stored.note), (30000, NOV, "Groceries"))
        self.assertEqual((result.budget_status.level, result.budget_status.remaining_paisa),
                         (NONE, 20000))
        self.assertIsNone(result.alert)
        self.assertEqual(self.alert_repo.find_for_user(uid), [])

    def test_C1_02_alerts_once_per_level_as_spending_rises(self):
        """C1-02 Validation + repeated input: 80%, 90%, 105% -> amber alert, none, red alert."""
        uid, cats = self.new_user()
        self.budgets.set_budget(uid, cats["Fun"], 11, 2026, 10000)

        alerts = [self.transactions.add_transaction(uid, paisa, E, cats["Fun"], NOV).alert
                  for paisa in (8000, 1000, 1500)]

        self.assertEqual([a.level if a else None for a in alerts], [AMBER, None, RED])
        self.assertEqual(len(self.alert_repo.find_for_user(uid)), 2)
        self.assertEqual(self.level(uid, cats["Fun"]), RED)

    def test_C1_03_interface_misunderstanding_rupees_instead_of_paisa(self):
        """C1-03 Interface misunderstanding: caller sends 25.0 (rupees) not 2500 (paisa)."""
        uid, cats = self.new_user()
        with self.assertRaises(ValidationError) as caught:
            self.transactions.add_transaction(uid, 25.0, E, cats["Food"], NOV)
        self.assertEqual(caught.exception.errors,
                         {"amount": "Amount must be a whole number of paisa"})
        self.assertEqual(self.tx_repo.count(uid), 0)

    def test_C1_04_interface_misuse_swapped_parameters(self):
        """C1-04 Interface misuse: amount and category_id passed in the wrong order."""
        uid, cats = self.new_user()
        with self.assertRaises(ValidationError) as caught:
            self.transactions.add_transaction(uid, cats["Food"], E, 2500, NOV)  # swapped
        self.assertEqual(caught.exception.errors, {"category": "Category is required"})
        self.assertEqual(self.tx_repo.count(uid), 0)

    def test_C1_05_failing_alert_store_rolls_back_everything(self):
        """C1-05 Make the called component fail: alert save errors -> nothing is half-saved."""
        uid, cats = self.new_user()
        self.budgets.set_budget(uid, cats["Food"], 11, 2026, 10000)
        self.alerts.alerts = FailingAlertRepository(self.conn)

        with self.assertRaises(sqlite3.OperationalError):
            self.transactions.add_transaction(uid, 9000, E, cats["Food"], NOV)

        self.assertEqual(self.tx_repo.count(uid), 0)                 # expense rolled back
        self.assertIsNotNone(self.budget_repo.find(uid, cats["Food"], 11, 2026))  # budget kept
        self.assertEqual(self.level(uid, cats["Food"]), NONE)          # level rolled back

    def test_C1_06_order_of_activation_spending_before_budget(self):
        """C1-06 Vary the order: expenses added BEFORE the budget exists are still counted."""
        uid, cats = self.new_user()
        first = self.transactions.add_transaction(uid, 9000, E, cats["Food"], NOV)
        self.assertIsNone(first.budget_status)                         # no budget yet

        self.budgets.set_budget(uid, cats["Food"], 11, 2026, 10000)
        later = self.transactions.add_transaction(uid, 100, E, cats["Food"], NOV)

        self.assertEqual((later.budget_status.spent_paisa, later.alert.level), (9100, AMBER))

    def test_C1_07_editing_category_leaves_no_stale_budget(self):
        """C1-07 Timing (out-of-date data): moving an expense Food -> Transport updates both."""
        uid, cats = self.new_user()
        for name in ("Food", "Transport"):
            self.budgets.set_budget(uid, cats[name], 11, 2026, 10000)
        tx = self.transactions.add_transaction(uid, 9000, E, cats["Food"], NOV).transaction

        edited = self.transactions.edit_transaction(uid, tx.id, 9000, E, cats["Transport"], NOV)

        self.assertEqual(edited.alert.level, AMBER)                   # Transport now 90%
        self.assertEqual(self.level(uid, cats["Food"]), NONE)          # Food not left amber
        self.assertEqual(self.budgets.status_for(uid, cats["Food"], 11, 2026)[1].spent_paisa, 0)

    def test_C1_08_delete_resets_level_so_alert_can_fire_again(self):
        """C1-08 State path via the interface: red, delete -> green, spend again -> new alert."""
        uid, cats = self.new_user()
        self.budgets.set_budget(uid, cats["Fun"], 11, 2026, 10000)
        big = self.transactions.add_transaction(uid, 12000, E, cats["Fun"], NOV)

        after_delete = self.transactions.delete_transaction(uid, big.transaction.id)
        again = self.transactions.add_transaction(uid, 8500, E, cats["Fun"], NOV)

        self.assertEqual((big.alert.level, after_delete.budget_status.level, again.alert.level),
                         (RED, NONE, AMBER))
        self.assertEqual(len(self.alert_repo.find_for_user(uid)), 2)  # old alert kept as history

    def test_C1_09_other_users_records_are_not_reachable(self):
        """C1-09 Missing/invalid references: user B uses A's category and A's transaction id."""
        a, a_cats = self.new_user("a@example.com")
        b, _ = self.new_user("b@example.com")
        tx = self.transactions.add_transaction(a, 1000, E, a_cats["Food"], NOV).transaction

        with self.assertRaises(ValidationError):
            self.transactions.add_transaction(b, 1000, E, a_cats["Food"], NOV)
        with self.assertRaises(NotFoundError):
            self.transactions.delete_transaction(b, tx.id)
        self.assertEqual((self.tx_repo.count(a), self.tx_repo.count(b)), (1, 0))


# ======================================================================================
# COMPONENT 2 - "Monthly summary report"
# Interface: ReportService.monthly_summary(user_id, month, year)
# Inside: TransactionRepository SQL aggregates (sum_by_type, expense_totals_by_category).
# The database is a SHARED-MEMORY interface: TransactionService writes it, ReportService
# reads it, so data is entered through TransactionService.
# Top categories is a SEQUENCE, so the Ch. 8 sequence guidelines are applied
# (zero length, one element, many elements with first/middle/last positions).
# ======================================================================================
class C2MonthlySummaryComponentTests(BudgetCashTestCase):

    def add(self, uid, cats, rows):
        for paisa, tx_type, name, day in rows:
            self.transactions.add_transaction(uid, paisa, tx_type, cats[name], day)

    def test_C2_01_full_summary_with_previous_month(self):
        """C2-01 Validation: totals, balance, top 3 categories and change vs October."""
        uid, cats = self.new_user()
        self.add(uid, cats, [
            (200000, I, "Salary", date(2026, 11, 1)),
            (30000, E, "Food", date(2026, 11, 3)), (15000, E, "Food", date(2026, 11, 9)),
            (20000, E, "Transport", date(2026, 11, 4)),
            (12000, E, "Fun", date(2026, 11, 6)), (4000, E, "Bills", date(2026, 11, 7)),
            (60000, E, "Food", date(2026, 10, 15)),
        ])

        s = self.reports.monthly_summary(uid, 11, 2026)

        self.assertEqual((s.total_income_paisa, s.total_expense_paisa, s.balance_paisa),
                         (200000, 81000, 119000))
        self.assertEqual([(c.name, c.total_paisa) for c in s.top_categories],
                         [("Food", 45000), ("Transport", 20000), ("Fun", 12000)])
        self.assertEqual((s.previous_expense_paisa, s.expense_change_paisa,
                          s.expense_change_percent), (60000, 21000, 35.0))

    def test_C2_02_sequence_of_length_zero(self):
        """C2-02 Sequence guideline, zero length: no transactions -> zeros, empty top list."""
        uid, _ = self.new_user()
        s = self.reports.monthly_summary(uid, 11, 2026)
        self.assertEqual((s.total_income_paisa, s.total_expense_paisa, s.balance_paisa),
                         (0, 0, 0))
        self.assertEqual(s.top_categories, [])
        self.assertIsNone(s.expense_change_percent)       # no division by zero

    def test_C2_03_sequence_of_one_element(self):
        """C2-03 Sequence guideline, single value: one expense, no previous month."""
        uid, cats = self.new_user()
        self.add(uid, cats, [(5000, E, "Bills", date(2026, 11, 2))])
        s = self.reports.monthly_summary(uid, 11, 2026)
        self.assertEqual([(c.name, c.total_paisa) for c in s.top_categories], [("Bills", 5000)])
        self.assertEqual((s.balance_paisa, s.expense_change_percent), (-5000, None))

    def test_C2_04_longer_sequence_is_ranked_and_cut_to_three(self):
        """C2-04 Sequence guideline, many values: 4 categories -> top 3, tie broken by name."""
        uid, cats = self.new_user()
        self.add(uid, cats, [
            (1000, E, "Transport", date(2026, 11, 1)),   # last
            (9000, E, "Food", date(2026, 11, 2)),        # first
            (3000, E, "Fun", date(2026, 11, 3)),         # tie with Bills
            (3000, E, "Bills", date(2026, 11, 4)),
        ])
        s = self.reports.monthly_summary(uid, 11, 2026)
        self.assertEqual([c.name for c in s.top_categories], ["Food", "Bills", "Fun"])

    def test_C2_05_extreme_month_values_january_and_december(self):
        """C2-05 Extreme parameters: January compares with December of the previous year."""
        uid, cats = self.new_user()
        self.add(uid, cats, [
            (10000, E, "Food", date(2025, 12, 31)),
            (4000, E, "Food", date(2026, 1, 1)), (1000, E, "Food", date(2026, 1, 31)),
            (9999, E, "Food", date(2026, 2, 1)),
        ])
        s = self.reports.monthly_summary(uid, 1, 2026)
        self.assertEqual((s.total_expense_paisa, s.previous_expense_paisa,
                          s.expense_change_percent), (5000, 10000, -50.0))

    def test_C2_06_summary_is_never_out_of_date(self):
        """C2-06 Timing: editing last month's expense changes the next summary immediately."""
        uid, cats = self.new_user()
        self.add(uid, cats, [(20000, E, "Food", date(2026, 11, 2))])
        october = self.transactions.add_transaction(uid, 40000, E, cats["Food"],
                                                    date(2026, 10, 2)).transaction
        before = self.reports.monthly_summary(uid, 11, 2026).expense_change_percent

        self.transactions.edit_transaction(uid, october.id, 10000, E, cats["Food"],
                                           date(2026, 10, 2))

        after = self.reports.monthly_summary(uid, 11, 2026).expense_change_percent
        self.assertEqual((before, after), (-50.0, 100.0))

    def test_C2_07_invalid_month_parameter(self):
        """C2-07 Interface misuse: month 0 and month 13 are rejected with ValueError."""
        uid, _ = self.new_user()
        for month in (0, 13):
            with self.subTest(month=month):
                with self.assertRaises(ValueError):
                    self.reports.monthly_summary(uid, month, 2026)

    def test_C2_08_other_users_data_is_excluded(self):
        """C2-08 Shared database: user B's spending never appears in user A's summary."""
        a, a_cats = self.new_user("a@example.com")
        b, b_cats = self.new_user("b@example.com")
        self.add(a, a_cats, [(1000, E, "Food", NOV)])
        self.add(b, b_cats, [(99900, E, "Food", NOV)])
        self.assertEqual(self.reports.monthly_summary(a, 11, 2026).total_expense_paisa, 1000)


if __name__ == "__main__":
    unittest.main()
