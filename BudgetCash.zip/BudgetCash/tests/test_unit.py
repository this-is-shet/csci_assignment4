
import unittest
from datetime import date, datetime

from budgetcash.alert_service import AlertService
from budgetcash.budget_service import calculate_status
from budgetcash.domain import (Alert, AlertLevel, Budget, Category, TransactionType,
                               ValidationError)
from budgetcash.money_util import format_paisa, to_paisa
from budgetcash.validation import MAX_AMOUNT_PAISA, MAX_NOTE_LENGTH, validate_transaction

E, I = TransactionType.EXPENSE, TransactionType.INCOME
NONE, AMBER, RED = AlertLevel.NONE, AlertLevel.APPROACHING, AlertLevel.EXCEEDED


# --------------------------------------------------------------------------------------
# UNIT 1 - MoneyUtil: to_paisa() and format_paisa()
# Partitions for to_paisa(text):
#   valid:   whole number | 1 decimal | 2 decimals | with thousands separators
#   invalid: empty / missing | non-numeric | negative | 3+ decimals
# --------------------------------------------------------------------------------------
class U1MoneyUtilTests(unittest.TestCase):

    def test_U1_01_normal_amounts_become_exact_paisa(self):
        """U1-01 Validation: typical typed amounts are converted to whole paisa."""
        cases = {"25.00": 2500, "1,250.75": 125075, "300": 30000}
        for text, expected in cases.items():
            with self.subTest(text=text):
                self.assertEqual(to_paisa(text), expected)

    def test_U1_02_decimal_places_boundary_two_accepted_three_rejected(self):
        """U1-02 Partition + boundary: 0, 1 and 2 decimals are valid; 3 decimals are not."""
        self.assertEqual(to_paisa("25"), 2500)
        self.assertEqual(to_paisa("25.5"), 2550)      # one decimal = 50 paisa, not 5
        self.assertEqual(to_paisa("25.05"), 2505)     # last valid value (2 decimals)
        with self.assertRaises(ValueError):
            to_paisa("25.055")                        # first invalid value (3 decimals)

    def test_U1_03_lowest_values_boundary(self):
        """U1-03 Boundary: 0 and 0.01 are accepted; -0.01 (just below zero) is rejected."""
        self.assertEqual(to_paisa("0"), 0)
        self.assertEqual(to_paisa("0.01"), 1)
        with self.assertRaises(ValueError):
            to_paisa("-0.01")

    def test_U1_04_every_error_message_is_produced(self):
        """U1-04 Guideline 'force all error messages': missing vs invalid amounts."""
        for missing in ("", "   ", None):
            with self.subTest(text=missing):
                with self.assertRaisesRegex(ValueError, "^Amount is required$"):
                    to_paisa(missing)
        for bad in ("abc", "1.2.3", "-5", "Rs 20"):
            with self.subTest(text=bad):
                with self.assertRaisesRegex(ValueError, "^Invalid amount"):
                    to_paisa(bad)

    def test_U1_05_large_results_stay_exact(self):
        """U1-05 Guideline 'results too large': big totals keep every paisa (no float drift)."""
        self.assertEqual(to_paisa("99,999,999,999.99"), 9_999_999_999_999)
        self.assertNotEqual(0.10 + 0.20, 0.30)        # the float problem the design avoids
        self.assertEqual(to_paisa("0.10") + to_paisa("0.20"), to_paisa("0.30"))

    def test_U1_06_format_for_display(self):
        """U1-06 Validation + edge: display text for normal, tiny, zero and negative values."""
        self.assertEqual(format_paisa(125075), "Rs 1,250.75")
        self.assertEqual(format_paisa(5), "Rs 0.05")
        self.assertEqual(format_paisa(0), "Rs 0.00")
        self.assertEqual(format_paisa(-500), "-Rs 5.00")

    def test_U1_07_format_rejects_rupee_floats(self):
        """U1-07 Defect: passing rupees as a float (12.5) instead of paisa raises TypeError."""
        with self.assertRaises(TypeError):
            format_paisa(12.5)


# --------------------------------------------------------------------------------------
# UNIT 2 - TransactionValidator: validate_transaction()
#   amount:   < 1 invalid low | 1 .. 1,000,000,000 valid | > 1,000,000,000 invalid high
#   date:     past or today valid | future invalid | not a plain date invalid
#   note:     0 .. 200 characters valid | 201+ invalid
#   category: same type as transaction valid | other type invalid | missing invalid
# --------------------------------------------------------------------------------------
TODAY = date(2026, 11, 19)
FOOD = Category(1, 1, "Food", E)
SALARY = Category(5, 1, "Salary", I)


def errors_for(**overrides):
    """Call the validator with a valid transaction, changing only the given fields.
    Returns the dict of field errors ({} when valid)."""
    args = dict(amount_paisa=2500, tx_type=E, category=FOOD, tx_date=date(2026, 10, 23),
                note="Lunch", today=TODAY)
    args.update(overrides)
    try:
        validate_transaction(**args)
        return {}
    except ValidationError as error:
        return error.errors


class U2TransactionValidatorTests(unittest.TestCase):

    def test_U2_01_prototype_expense_is_valid(self):
        """U2-01 Validation: the Add Transaction prototype (Rs 25.00 Food, 'Lunch') passes."""
        self.assertEqual(errors_for(), {})

    def test_U2_02_amount_partitions_and_both_boundaries(self):
        """U2-02 Partition + boundary: 0|1 and 1,000,000,000|1,000,000,001 paisa."""
        expected = {0: False, 1: True, 50_000: True,
                    MAX_AMOUNT_PAISA: True, MAX_AMOUNT_PAISA + 1: False}
        for amount, valid in expected.items():
            with self.subTest(amount=amount):
                self.assertEqual("amount" not in errors_for(amount_paisa=amount), valid)

    def test_U2_03_date_boundary_today_and_tomorrow(self):
        """U2-03 Partition + boundary: yesterday and today are valid; tomorrow is not."""
        self.assertEqual(errors_for(tx_date=date(2026, 11, 18)), {})
        self.assertEqual(errors_for(tx_date=TODAY), {})
        self.assertEqual(errors_for(tx_date=date(2026, 11, 20)),
                         {"date": "Date cannot be in the future"})

    def test_U2_04_note_length_boundary_200_and_201(self):
        """U2-04 Guideline 'overflow the input buffer': 200 characters pass, 201 fail."""
        self.assertEqual(errors_for(note=""), {})
        self.assertEqual(errors_for(note="x" * MAX_NOTE_LENGTH), {})
        self.assertEqual(list(errors_for(note="x" * (MAX_NOTE_LENGTH + 1))), ["note"])

    def test_U2_05_category_must_exist_and_match_type(self):
        """U2-05 Defect: an expense using the income category 'Salary', or no category."""
        self.assertIn("cannot be used for EXPENSE", errors_for(category=SALARY)["category"])
        self.assertEqual(errors_for(category=None), {"category": "Category is required"})

    def test_U2_06_date_with_time_or_text_is_rejected(self):
        """U2-06 Defect: a datetime (has a time of day) or a text date is not a plain date."""
        for bad in (datetime(2026, 11, 1, 23, 30), "2026-11-01"):
            with self.subTest(value=bad):
                self.assertEqual(errors_for(tx_date=bad),
                                 {"date": "Date must be a calendar date"})

    def test_U2_07_every_error_message_in_one_submission(self):
        """U2-07 Guideline 'force all error messages': five bad fields, five messages."""
        errors = errors_for(amount_paisa=-100, tx_type="EXPENSE", category=None,
                            tx_date=date(2027, 1, 1), note="x" * 300)
        self.assertEqual(errors, {
            "amount": "Amount must be greater than zero",
            "type": "Type must be INCOME or EXPENSE",
            "category": "Category is required",
            "date": "Date cannot be in the future",
            "note": "Note must be 200 characters or fewer",
        })


# --------------------------------------------------------------------------------------
# UNIT 3 - Budget status: calculate_status(spent, limit)
# Output partitions (Assignment 3 state diagram):
#   green  0% .. <80%  |  amber 80% .. <100%  |  red >= 100%
# Input partitions: limit > 0 valid | limit <= 0 or not an int invalid; spent < 0 invalid
# --------------------------------------------------------------------------------------
class U3BudgetStatusTests(unittest.TestCase):

    def test_U3_01_normal_spending_is_green(self):
        """U3-01 Validation: Rs 300 of a Rs 500 Food budget -> 60%, Rs 200 left, green."""
        status = calculate_status(30000, 50000)
        self.assertEqual((status.percent_used, status.remaining_paisa, status.colour),
                         (60.0, 20000, "green"))

    def test_U3_02_boundary_at_80_percent(self):
        """U3-02 Boundary: 79.998% is green; exactly 80% is amber (limit Rs 500)."""
        self.assertEqual(calculate_status(39999, 50000).level, NONE)
        self.assertEqual(calculate_status(40000, 50000).level, AMBER)

    def test_U3_03_boundary_at_100_percent(self):
        """U3-03 Boundary: 99.998% is amber; exactly 100% is red."""
        self.assertEqual(calculate_status(49999, 50000).level, AMBER)
        self.assertEqual(calculate_status(50000, 50000).level, RED)

    def test_U3_04_overspent_has_negative_remaining(self):
        """U3-04 Partition red: prototype 'Fun 105%' shows Rs -5.00 remaining."""
        status = calculate_status(10500, 10000)
        self.assertEqual((status.level, status.percent_used, status.remaining_paisa),
                         (RED, 105.0, -500))

    def test_U3_05_nothing_spent(self):
        """U3-05 Edge: an empty month is green at 0% with the whole limit remaining."""
        status = calculate_status(0, 10000)
        self.assertEqual((status.level, status.percent_used, status.remaining_paisa),
                         (NONE, 0.0, 10000))

    def test_U3_06_invalid_limit_or_spent(self):
        """U3-06 Defect: limit 0, negative or float, or negative spending -> ValueError."""
        for spent, limit in [(100, 0), (100, -5), (100, 10.5), (-1, 100)]:
            with self.subTest(spent=spent, limit=limit):
                with self.assertRaises(ValueError):
                    calculate_status(spent, limit)

    def test_U3_07_awkward_limit_and_huge_values(self):
        """U3-07 Guideline 'results too large/small': 80% of an odd limit, and a huge total."""
        self.assertEqual(calculate_status(9875, 12345).level, NONE)   # 79.99%
        self.assertEqual(calculate_status(9876, 12345).level, AMBER)  # exactly 80%
        self.assertEqual(calculate_status(10**15, 1).level, RED)


# --------------------------------------------------------------------------------------
# UNIT 4 - AlertService.check_budget() tested as an OBJECT with states
# State model from Assignment 3 (Figure 6): NONE (green) -> APPROACHING (amber) -> EXCEEDED (red)
# Ch. 8: "identify sequences of state transitions to be tested".
# The repositories are replaced by the fakes below (no database).
# --------------------------------------------------------------------------------------
class FakeBudgetRepository:
    def __init__(self):
        self.updates = []

    def update(self, budget):
        self.updates.append(budget.last_alert_level)


class FakeAlertRepository:
    def __init__(self, fail=False):
        self.saved, self.fail = [], fail

    def save(self, alert):
        if self.fail:
            raise RuntimeError("disk full")
        alert.id = len(self.saved) + 1
        self.saved.append(alert)
        return alert


class FakeCategoryRepository:
    def __init__(self, category):
        self.category = category

    def find(self, user_id, category_id):
        return self.category


class U4AlertServiceTests(unittest.TestCase):

    def setUp(self):
        self.budgets = FakeBudgetRepository()
        self.alerts = FakeAlertRepository()
        self.service = AlertService(self.budgets, self.alerts,
                                    FakeCategoryRepository(Category(4, 1, "Fun", E)))
        self.budget = Budget(7, 1, 4, 11, 2026, 10000, NONE)   # Rs 100 Fun budget

    def spend(self, paisa):
        """Tell the service the budget's spending is now `paisa`; return the alert (or None)."""
        return self.service.check_budget(self.budget, calculate_status(paisa, 10000))

    def test_U4_01_green_to_amber_creates_one_alert(self):
        """U4-01 Validation, transition NONE -> APPROACHING: one alert, level stored."""
        alert = self.spend(8500)
        self.assertEqual((alert.level, alert.message),
                         (AMBER, "Fun budget at 85%: Rs 15.00 left"))
        self.assertEqual(self.budget.last_alert_level, AMBER)
        self.assertEqual(self.budgets.updates, [AMBER])

    def test_U4_02_repeating_the_same_level_never_repeats_the_alert(self):
        """U4-02 Guideline 'repeat the same input': amber, then amber x3 -> still 1 alert."""
        self.spend(8000)
        for paisa in (8500, 9000, 9900):
            self.assertIsNone(self.spend(paisa))
        self.assertEqual(len(self.alerts.saved), 1)
        self.assertEqual(self.budgets.updates, [AMBER])

    def test_U4_03_green_straight_to_red(self):
        """U4-03 Transition NONE -> EXCEEDED (skips amber) in one large expense."""
        alert = self.spend(10500)
        self.assertEqual((alert.level, alert.message),
                         (RED, "Fun budget exceeded: spent Rs 105.00 of Rs 100.00"))

    def test_U4_04_full_state_path_and_alert_again_after_reset(self):
        """U4-04 State sequence NONE -> AMBER -> RED -> NONE -> AMBER: three alerts."""
        for paisa in (8000, 10000, 1000, 8000):
            self.spend(paisa)
        self.assertEqual([a.level for a in self.alerts.saved], [AMBER, RED, AMBER])
        self.assertEqual(self.budgets.updates, [AMBER, RED, NONE, AMBER])

    def test_U4_05_dropping_one_level_lowers_state_without_alert(self):
        """U4-05 Transition EXCEEDED -> APPROACHING (expense edited down): no alert."""
        self.budget.last_alert_level = RED
        self.assertIsNone(self.spend(9000))
        self.assertEqual(self.budget.last_alert_level, AMBER)
        self.assertEqual(self.alerts.saved, [])

    def test_U4_06_failure_of_alert_storage_is_reported(self):
        """U4-06 Defect: if saving the alert fails, the error reaches the caller."""
        self.service.alerts = FakeAlertRepository(fail=True)
        with self.assertRaisesRegex(RuntimeError, "disk full"):
            self.spend(10000)

    def test_U4_07_missing_category_uses_generic_name(self):
        """U4-07 Guideline 'null references': category not found -> readable generic message."""
        self.service.categories = FakeCategoryRepository(None)
        self.assertEqual(self.spend(8000).message, "Budget at 80%: Rs 20.00 left")


if __name__ == "__main__":
    unittest.main()
