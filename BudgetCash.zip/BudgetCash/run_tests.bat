@echo off
setlocal
cd /d "%~dp0"

echo Checking Python...
python --version
if errorlevel 1 goto failure

echo.
echo === 1. UNIT TESTS: 4 units in isolation (fakes, no database) ===
python -m unittest tests.test_unit -v
if errorlevel 1 goto failure

echo.
echo === 2. COMPONENT TESTS: 2 components on temporary SQLite databases ===
python -m unittest tests.test_component -v
if errorlevel 1 goto failure

echo.
echo All BudgetCash tests passed.
pause
exit /b 0

:failure
echo.
echo A test or command failed. Review the output above.
pause
exit /b 1
