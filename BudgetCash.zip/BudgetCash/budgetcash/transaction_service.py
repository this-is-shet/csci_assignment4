
from dataclasses import dataclass
from datetime import date
from typing import Optional

from .domain import (Alert, BudgetStatus, NotFoundError, Transaction,
                     TransactionType, ValidationError)
from .validation import validate_transaction


@dataclass
class TransactionResult:
    transaction: Optional[Transaction]
    budget_status: Optional[BudgetStatus]
    alert: Optional[Alert]


class TransactionService:
    def __init__(self, conn, transaction_repo, category_repo, budget_service, alert_service,
                 today=None):
        self.conn = conn
        self.transactions = transaction_repo
        self.categories = category_repo
        self.budget_service = budget_service
        self.alert_service = alert_service
        self._today = today or date.today

    def _recalculate(self, user_id, category_id, tx_date: date):
        budget, status = self.budget_service.status_for(
            user_id, category_id, tx_date.month, tx_date.year)
        if budget is None:
            return None, None
        alert = self.alert_service.check_budget(budget, status)
        return status, alert

    def add_transaction(self, user_id, amount_paisa, tx_type: TransactionType, category_id,
                        tx_date: date, note: str = "") -> TransactionResult:
        category = self.categories.find(user_id, category_id)
        validate_transaction(amount_paisa, tx_type, category, tx_date, note, today=self._today())
        with self.conn:  # commit on success, roll back on any exception
            tx = self.transactions.save(Transaction(None, user_id, amount_paisa, tx_type,
                                                    category_id, tx_date, note))
            status, alert = self._recalculate(user_id, category_id, tx_date)
        return TransactionResult(tx, status, alert)

    def edit_transaction(self, user_id, tx_id, amount_paisa, tx_type, category_id, tx_date,
                         note="") -> TransactionResult:
        old = self.transactions.find(user_id, tx_id)
        if old is None:
            raise NotFoundError(f"Transaction {tx_id} not found")
        category = self.categories.find(user_id, category_id)
        validate_transaction(amount_paisa, tx_type, category, tx_date, note, today=self._today())
        with self.conn:
            new = Transaction(tx_id, user_id, amount_paisa, tx_type, category_id, tx_date, note)
            self.transactions.update(new)
            # Design decision 2: if category or month changed, recalc the old budget too.
            if (old.category_id, old.date.month, old.date.year) != \
                    (category_id, tx_date.month, tx_date.year):
                self._recalculate(user_id, old.category_id, old.date)
            status, alert = self._recalculate(user_id, category_id, tx_date)
        return TransactionResult(new, status, alert)

    def delete_transaction(self, user_id, tx_id) -> TransactionResult:
        old = self.transactions.find(user_id, tx_id)
        if old is None:
            raise NotFoundError(f"Transaction {tx_id} not found")
        with self.conn:
            self.transactions.delete(user_id, tx_id)
            status, alert = self._recalculate(user_id, old.category_id, old.date)
        return TransactionResult(None, status, alert)
