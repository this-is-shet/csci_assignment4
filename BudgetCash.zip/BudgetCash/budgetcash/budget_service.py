"""BudgetService: budget status (Unit 3) plus budget creation and roll-over."""
from .domain import AlertLevel, Budget, BudgetStatus, TransactionType, ValidationError

APPROACHING_PERCENT = 80
EXCEEDED_PERCENT = 100


def calculate_status(spent_paisa: int, limit_paisa: int) -> BudgetStatus:
  
    if not isinstance(limit_paisa, int) or limit_paisa <= 0:
        raise ValueError("Budget limit must be a positive number of paisa")
    if not isinstance(spent_paisa, int) or spent_paisa < 0:
        raise ValueError("Spent amount cannot be negative")

    if spent_paisa * 100 >= limit_paisa * EXCEEDED_PERCENT:
        level = AlertLevel.EXCEEDED
    elif spent_paisa * 100 >= limit_paisa * APPROACHING_PERCENT:
        level = AlertLevel.APPROACHING
    else:
        level = AlertLevel.NONE

    percent = round(spent_paisa * 100 / limit_paisa, 1)  # display only
    return BudgetStatus(spent_paisa, limit_paisa, limit_paisa - spent_paisa, percent, level)


class BudgetService:
    def __init__(self, conn, budget_repo, category_repo, transaction_repo):
        self.conn = conn  # BUG FIX (A4): set_budget/roll_over must commit their own work
        self.budgets = budget_repo
        self.categories = category_repo
        self.transactions = transaction_repo

    def set_budget(self, user_id, category_id, month, year, limit_paisa) -> Budget:
        category = self.categories.find(user_id, category_id)
        if category is None or category.type != TransactionType.EXPENSE:
            raise ValidationError({"category": "Budgets can only be set on expense categories"})
        if not isinstance(limit_paisa, int) or limit_paisa <= 0:
            raise ValidationError({"limit": "Limit must be greater than zero"})
        with self.conn:
            existing = self.budgets.find(user_id, category_id, month, year)
            if existing:
                existing.limit_paisa = limit_paisa
                self.budgets.update(existing)
                return existing
            return self.budgets.save(Budget(None, user_id, category_id, month, year, limit_paisa))

    def status_for(self, user_id, category_id, month, year):
        """Return (budget, status) for a category/month, or (None, None) if no budget."""
        budget = self.budgets.find(user_id, category_id, month, year)
        if budget is None:
            return None, None
        spent = self.transactions.sum_by_category(user_id, category_id, month, year)
        return budget, calculate_status(spent, budget.limit_paisa)

    def roll_over_budgets(self, user_id, month, year) -> int:
        """Copy last month's budgets into (month, year) if none exist yet."""
        if self.budgets.find_for_month(user_id, month, year):
            return 0
        prev_month, prev_year = (12, year - 1) if month == 1 else (month - 1, year)
        copied = 0
        with self.conn:
            for b in self.budgets.find_for_month(user_id, prev_month, prev_year):
                self.budgets.save(Budget(None, user_id, b.category_id, month, year, b.limit_paisa))
                copied += 1
        return copied
