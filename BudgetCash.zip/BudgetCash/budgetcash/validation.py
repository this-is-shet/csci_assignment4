
from datetime import date, datetime

from .domain import Category, TransactionType, ValidationError

MAX_AMOUNT_PAISA = 1_000_000_000  # Rs 10,000,000.00 per transaction
MAX_NOTE_LENGTH = 200


def validate_transaction(amount_paisa, tx_type, category: Category, tx_date,
                         note: str = "", today: date = None) -> None:
   
    today = today or date.today()
    errors = {}

    if not isinstance(amount_paisa, int) or isinstance(amount_paisa, bool):
        errors["amount"] = "Amount must be a whole number of paisa"
    elif amount_paisa <= 0:
        errors["amount"] = "Amount must be greater than zero"
    elif amount_paisa > MAX_AMOUNT_PAISA:
        errors["amount"] = "Amount is above the maximum allowed"

    if not isinstance(tx_type, TransactionType):
        errors["type"] = "Type must be INCOME or EXPENSE"

    if category is None:
        errors["category"] = "Category is required"
    elif isinstance(tx_type, TransactionType) and category.type != tx_type:
        errors["category"] = (f"Category '{category.name}' is a {category.type.value} "
                              f"category and cannot be used for {tx_type.value}")

    # datetime is a subclass of date, so reject it explicitly (date-only rule).
    if not isinstance(tx_date, date) or isinstance(tx_date, datetime):
        errors["date"] = "Date must be a calendar date"
    elif tx_date > today:
        errors["date"] = "Date cannot be in the future"

    if note is not None and len(note) > MAX_NOTE_LENGTH:
        errors["note"] = f"Note must be {MAX_NOTE_LENGTH} characters or fewer"

    if errors:
        raise ValidationError(errors)
