
import re

_AMOUNT_RE = re.compile(r"^(\d+)(?:\.(\d{1,2}))?$")


def to_paisa(text: str) -> int:
   
    if text is None:
        raise ValueError("Amount is required")
    cleaned = str(text).strip().replace(",", "")
    if cleaned == "":
        raise ValueError("Amount is required")
    match = _AMOUNT_RE.match(cleaned)
    if not match:
        raise ValueError(f"Invalid amount: {text!r}")
    whole, frac = match.group(1), match.group(2) or ""
    frac = frac.ljust(2, "0")  # "5" -> "50" paisa, not 5 paisa
    return int(whole) * 100 + int(frac)


def format_paisa(paisa: int, symbol: str = "Rs") -> str:
    """Format paisa for display, e.g. 125075 -> "Rs 1,250.75", -500 -> "-Rs 5.00"."""
    if not isinstance(paisa, int) or isinstance(paisa, bool):
        raise TypeError("Amount must be a whole number of paisa (int)")
    sign = "-" if paisa < 0 else ""
    whole, frac = divmod(abs(paisa), 100)
    return f"{sign}{symbol} {whole:,}.{frac:02d}"
