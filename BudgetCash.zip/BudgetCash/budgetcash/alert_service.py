"""AlertService (Unit 4): raises an alert only when a budget moves to a higher level.

Implements design decision 1 from Assignment 3 (no repeated alerts).
"""
from .domain import Alert, AlertLevel, Budget, BudgetStatus
from .money_util import format_paisa


class AlertService:
    def __init__(self, budget_repo, alert_repo, category_repo):
        self.budgets = budget_repo
        self.alerts = alert_repo
        self.categories = category_repo

    def check_budget(self, budget: Budget, status: BudgetStatus):
        """Compare the live level with budget.last_alert_level.

        Returns the new Alert if one was created, otherwise None.
        """
        new_level = status.level
        old_level = AlertLevel(budget.last_alert_level)

        if new_level == old_level:
            return None

        budget.last_alert_level = new_level
        self.budgets.update(budget)

        if new_level < old_level:
            # Budget dropped back (edit/delete): lower the stored level, no alert.
            return None

        category = self.categories.find(budget.user_id, budget.category_id)
        # BUG FIX (A4, U4-07): fallback used to read "Budget budget at 80%".
        label = f"{category.name} budget" if category else "Budget"
        if new_level == AlertLevel.EXCEEDED:
            msg = (f"{label} exceeded: spent {format_paisa(status.spent_paisa)} "
                   f"of {format_paisa(status.limit_paisa)}")
        else:
            msg = (f"{label} at {status.percent_used:g}%: "
                   f"{format_paisa(status.remaining_paisa)} left")
        return self.alerts.save(Alert(None, budget.user_id, budget.id, new_level, msg))
