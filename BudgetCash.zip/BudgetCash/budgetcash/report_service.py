"""ReportService: builds the monthly summary on request (never stored)."""
from .domain import MonthlySummary, TransactionType


def previous_month(month: int, year: int):
    return (12, year - 1) if month == 1 else (month - 1, year)


class ReportService:
    def __init__(self, transaction_repo):
        self.transactions = transaction_repo

    def monthly_summary(self, user_id, month, year, top_n: int = 3) -> MonthlySummary:
        if not 1 <= month <= 12:
            raise ValueError("Month must be between 1 and 12")
        income = self.transactions.sum_by_type(user_id, TransactionType.INCOME, month, year)
        expense = self.transactions.sum_by_type(user_id, TransactionType.EXPENSE, month, year)
        top = self.transactions.expense_totals_by_category(user_id, month, year)[:top_n]

        pm, py = previous_month(month, year)
        prev_expense = self.transactions.sum_by_type(user_id, TransactionType.EXPENSE, pm, py)
        change = expense - prev_expense
        change_pct = None if prev_expense == 0 else round(change * 100 / prev_expense, 1)

        return MonthlySummary(month, year, income, expense, income - expense, top,
                              prev_expense, change, change_pct)
