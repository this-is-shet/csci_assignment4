"""Database setup. Tables mirror the Assignment 3 class diagram."""
import sqlite3

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY,
    email TEXT NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS categories (
    id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id),
    name TEXT NOT NULL,
    type TEXT NOT NULL CHECK (type IN ('INCOME','EXPENSE')),
    is_default INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id),
    amount_paisa INTEGER NOT NULL CHECK (amount_paisa > 0),
    type TEXT NOT NULL CHECK (type IN ('INCOME','EXPENSE')),
    category_id INTEGER NOT NULL REFERENCES categories(id),
    tx_date TEXT NOT NULL,
    note TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS budgets (
    id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id),
    category_id INTEGER NOT NULL REFERENCES categories(id),
    month INTEGER NOT NULL CHECK (month BETWEEN 1 AND 12),
    year INTEGER NOT NULL,
    limit_paisa INTEGER NOT NULL CHECK (limit_paisa > 0),
    last_alert_level INTEGER NOT NULL DEFAULT 0,
    UNIQUE (user_id, category_id, month, year)
);
CREATE TABLE IF NOT EXISTS alerts (
    id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id),
    budget_id INTEGER NOT NULL REFERENCES budgets(id),
    level INTEGER NOT NULL CHECK (level IN (1, 2)),
    message TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
"""

DEFAULT_CATEGORIES = [("Food", "EXPENSE"), ("Transport", "EXPENSE"), ("Bills", "EXPENSE"),
                      ("Fun", "EXPENSE"), ("Salary", "INCOME")]


def connect(path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.executescript(SCHEMA)
    return conn


def create_user(conn, email: str) -> int:
    """Create a user and give them their own copy of the default categories."""
    with conn:
        cur = conn.execute("INSERT INTO users (email) VALUES (?)", (email,))
        user_id = cur.lastrowid
        conn.executemany(
            "INSERT INTO categories (user_id, name, type, is_default) VALUES (?, ?, ?, 1)",
            [(user_id, n, t) for n, t in DEFAULT_CATEGORIES])
    return user_id
