
from datetime import date

from .domain import (Alert, AlertLevel, Budget, Category, CategoryTotal,
                     Transaction, TransactionType)


def month_range(month: int, year: int):
    start = date(year, month, 1)
    end = date(year + 1, 1, 1) if month == 12 else date(year, month + 1, 1)
    return start.isoformat(), end.isoformat()


class CategoryRepository:
    def __init__(self, conn):
        self.conn = conn

    def find(self, user_id, category_id):
        row = self.conn.execute(
            "SELECT * FROM categories WHERE id = ? AND user_id = ?",
            (category_id, user_id)).fetchone()
        if row is None:
            return None
        return Category(row["id"], row["user_id"], row["name"],
                        TransactionType(row["type"]), bool(row["is_default"]))

    def find_by_name(self, user_id, name):
        row = self.conn.execute(
            "SELECT id FROM categories WHERE user_id = ? AND name = ?",
            (user_id, name)).fetchone()
        return self.find(user_id, row["id"]) if row else None


class TransactionRepository:
    def __init__(self, conn):
        self.conn = conn

    def save(self, tx: Transaction) -> Transaction:
        cur = self.conn.execute(
            "INSERT INTO transactions (user_id, amount_paisa, type, category_id, tx_date, note) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (tx.user_id, tx.amount_paisa, tx.type.value, tx.category_id,
             tx.date.isoformat(), tx.note or ""))
        tx.id = cur.lastrowid
        return tx

    def find(self, user_id, tx_id):
        row = self.conn.execute(
            "SELECT * FROM transactions WHERE id = ? AND user_id = ?", (tx_id, user_id)).fetchone()
        if row is None:
            return None
        return Transaction(row["id"], row["user_id"], row["amount_paisa"],
                           TransactionType(row["type"]), row["category_id"],
                           date.fromisoformat(row["tx_date"]), row["note"])

    def update(self, tx: Transaction):
        self.conn.execute(
            "UPDATE transactions SET amount_paisa = ?, type = ?, category_id = ?, tx_date = ?, "
            "note = ? WHERE id = ? AND user_id = ?",
            (tx.amount_paisa, tx.type.value, tx.category_id, tx.date.isoformat(),
             tx.note or "", tx.id, tx.user_id))

    def delete(self, user_id, tx_id):
        self.conn.execute("DELETE FROM transactions WHERE id = ? AND user_id = ?", (tx_id, user_id))

    def count(self, user_id) -> int:
        return self.conn.execute(
            "SELECT COUNT(*) FROM transactions WHERE user_id = ?", (user_id,)).fetchone()[0]

    def sum_by_category(self, user_id, category_id, month, year) -> int:
        start, end = month_range(month, year)
        return self.conn.execute(
            "SELECT COALESCE(SUM(amount_paisa), 0) FROM transactions "
            "WHERE user_id = ? AND category_id = ? AND type = 'EXPENSE' "
            "AND tx_date >= ? AND tx_date < ?",
            (user_id, category_id, start, end)).fetchone()[0]

    def sum_by_type(self, user_id, tx_type: TransactionType, month, year) -> int:
        start, end = month_range(month, year)
        return self.conn.execute(
            "SELECT COALESCE(SUM(amount_paisa), 0) FROM transactions "
            "WHERE user_id = ? AND type = ? AND tx_date >= ? AND tx_date < ?",
            (user_id, tx_type.value, start, end)).fetchone()[0]

    def expense_totals_by_category(self, user_id, month, year):
        start, end = month_range(month, year)
        rows = self.conn.execute(
            "SELECT c.id, c.name, SUM(t.amount_paisa) AS total FROM transactions t "
            "JOIN categories c ON c.id = t.category_id "
            "WHERE t.user_id = ? AND t.type = 'EXPENSE' AND t.tx_date >= ? AND t.tx_date < ? "
            "GROUP BY c.id, c.name ORDER BY total DESC, c.name ASC",
            (user_id, start, end)).fetchall()
        return [CategoryTotal(r["id"], r["name"], r["total"]) for r in rows]


class BudgetRepository:
    def __init__(self, conn):
        self.conn = conn

    @staticmethod
    def _to_budget(row):
        return Budget(row["id"], row["user_id"], row["category_id"], row["month"], row["year"],
                      row["limit_paisa"], AlertLevel(row["last_alert_level"]))

    def save(self, b: Budget) -> Budget:
        cur = self.conn.execute(
            "INSERT INTO budgets (user_id, category_id, month, year, limit_paisa, last_alert_level) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (b.user_id, b.category_id, b.month, b.year, b.limit_paisa, int(b.last_alert_level)))
        b.id = cur.lastrowid
        return b

    def update(self, b: Budget):
        self.conn.execute(
            "UPDATE budgets SET limit_paisa = ?, last_alert_level = ? WHERE id = ? AND user_id = ?",
            (b.limit_paisa, int(b.last_alert_level), b.id, b.user_id))

    def find(self, user_id, category_id, month, year):
        row = self.conn.execute(
            "SELECT * FROM budgets WHERE user_id = ? AND category_id = ? AND month = ? AND year = ?",
            (user_id, category_id, month, year)).fetchone()
        return self._to_budget(row) if row else None

    def find_for_month(self, user_id, month, year):
        rows = self.conn.execute(
            "SELECT * FROM budgets WHERE user_id = ? AND month = ? AND year = ?",
            (user_id, month, year)).fetchall()
        return [self._to_budget(r) for r in rows]


class AlertRepository:
    def __init__(self, conn):
        self.conn = conn

    def save(self, a: Alert) -> Alert:
        cur = self.conn.execute(
            "INSERT INTO alerts (user_id, budget_id, level, message) VALUES (?, ?, ?, ?)",
            (a.user_id, a.budget_id, int(a.level), a.message))
        a.id = cur.lastrowid
        return a

    def find_for_user(self, user_id):
        rows = self.conn.execute(
            "SELECT * FROM alerts WHERE user_id = ? ORDER BY id", (user_id,)).fetchall()
        return [Alert(r["id"], r["user_id"], r["budget_id"], AlertLevel(r["level"]), r["message"])
                for r in rows]
