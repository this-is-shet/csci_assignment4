
from dataclasses import dataclass, field
from datetime import date
from enum import Enum, IntEnum
from typing import Optional


class TransactionType(str, Enum):
    INCOME = "INCOME"
    EXPENSE = "EXPENSE"


class AlertLevel(IntEnum):

    NONE = 0
    APPROACHING = 1
    EXCEEDED = 2


@dataclass
class Category:
    id: Optional[int]
    user_id: int
    name: str
    type: TransactionType
    is_default: bool = False


@dataclass
class Transaction:
    id: Optional[int]
    user_id: int
    amount_paisa: int
    type: TransactionType
    category_id: int
    date: date
    note: str = ""


@dataclass
class Budget:
    id: Optional[int]
    user_id: int
    category_id: int
    month: int
    year: int
    limit_paisa: int
    last_alert_level: AlertLevel = AlertLevel.NONE


@dataclass
class Alert:
    id: Optional[int]
    user_id: int
    budget_id: int
    level: AlertLevel
    message: str


@dataclass
class BudgetStatus:
    spent_paisa: int
    limit_paisa: int
    remaining_paisa: int
    percent_used: float
    level: AlertLevel

    @property
    def colour(self) -> str:
        return {AlertLevel.NONE: "green",
                AlertLevel.APPROACHING: "amber",
                AlertLevel.EXCEEDED: "red"}[self.level]


@dataclass
class CategoryTotal:
    category_id: int
    name: str
    total_paisa: int


@dataclass
class MonthlySummary:
    """DTO: calculated on request by ReportService, never stored."""
    month: int
    year: int
    total_income_paisa: int
    total_expense_paisa: int
    balance_paisa: int
    top_categories: list = field(default_factory=list)
    previous_expense_paisa: int = 0
    expense_change_paisa: int = 0
    expense_change_percent: Optional[float] = None


class ValidationError(ValueError):
    """Raised when user input breaks a business rule. `errors` maps field -> message."""

    def __init__(self, errors: dict):
        self.errors = errors
        super().__init__("; ".join(f"{k}: {v}" for k, v in errors.items()))


class NotFoundError(LookupError):
    pass
